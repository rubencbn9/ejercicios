package bookadvisor.bookadvisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookadvisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
