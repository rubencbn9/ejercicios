package ejercicio36.calculadora.controllers;

public enum CalculadoraEstado {
    OPERANDO_1,OPERANDO_2,RESULTADO
}
