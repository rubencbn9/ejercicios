package ejercicio15v2;

public interface Domotica {
    
    Boolean Subir();
    Boolean Bajar();
    void reset();
    String verEstado();

}
