package ejercicio15;

public class Ascensor extends Elementos{
    public Ascensor(){
        super(0, 8, 0, 0, "Ascensor");
    }
    
}
