package ejercicio15;

public class Radio extends Elementos {
    public Radio(){
        super((int)(88.0 * 10), (int)(104.0 * 10), (int)(88.0 * 10), (int)(88.0 * 10), "Radio");
    
}
}